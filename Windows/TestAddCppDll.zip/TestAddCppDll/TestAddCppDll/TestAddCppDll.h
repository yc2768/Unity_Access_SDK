#ifndef _TEST_ADD_CPP_DLL_H_
#define _TEST_ADD_CPP_DLL_H_
#endif

#if defined (EXPORTBUILD)
#define _DLLExport _declspec (dllexport)
#else
#define _DLLExport _declspec (dllexport)
#endif

extern "C" int _DLLExport Add(int x,int y);

_DLLExport class TestAddCppDll
{
public:
	TestAddCppDll(void);
	~TestAddCppDll(void);
};