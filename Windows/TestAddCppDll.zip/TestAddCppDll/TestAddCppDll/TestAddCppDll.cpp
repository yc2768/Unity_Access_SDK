#define EXPORTBUILD

#include "TestAddCppDll.h"

int Add(int x,int y)
{
	return x+y;
}

TestAddCppDll::TestAddCppDll(void)
{

}

TestAddCppDll::~TestAddCppDll(void)
{

}